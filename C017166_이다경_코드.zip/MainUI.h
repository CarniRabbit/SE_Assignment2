// <<Boundary>> MainUI
#ifndef MAINUI_H
#define MAINUI_H

class MainUI {
public:
    void showUserMenu();
    void clickLogout();
    void redirectToLogin();
};

#endif