// <<Boundary>> RentalStatusUI
#ifndef RENTALSTATUSUI_H
#define RENTALSTATUSUI_H

#include "RentInfo.h"
#include <vector>

using namespace std;

class RentalStatusUI {
public:
    void showCurrentRentals();
};

#endif
