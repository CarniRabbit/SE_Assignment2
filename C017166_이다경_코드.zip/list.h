#include "User.h"
#include "Bicycle.h"
#include <vector>
#include "Session.h"

extern vector<User> userList;
extern vector<Bicycle> bicycleList;
extern Session activeSession;
extern vector<RentInfo> currentRentInfo;