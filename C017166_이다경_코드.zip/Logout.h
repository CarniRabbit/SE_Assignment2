// <<Control>> Logout
#ifndef LOGOUT_H
#define LOGOUT_H
#include "Session.h"

using namespace std;

class Logout {
public:
    void processLogout(Session& session);
};

#endif
