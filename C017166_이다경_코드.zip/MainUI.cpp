#include "MainUI.h"
#include "list.h"

void MainUI::clickLogout()
{
	activeSession.exitSession();
}
